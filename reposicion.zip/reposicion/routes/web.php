<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmpleadoController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProveedorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/api/empleados', [EmpleadoController::class, 'index'])->name('empleado.index');
Route::get('/api/empleados/nvo', [EmpleadoController::class, "create"])->name('empleado.form');
Route::post('/api/empleados/nvo/guardar',[EmpleadoController::class, 'store'])->name('empleado.crear');

Route::get('/api/productos', [ProductoController::class, 'index'])->name('producto.index');
Route::get('/api/productos/nvo', [ProductoController::class, "create"])->name('producto.form');
Route::post('/api/productos/nvo/guardar',[ProductoController::class, 'store'])->name('producto.crear');

Route::get('/api/proveedores', [ProveedorController::class, 'index'])->name('proveedor.index');
Route::get('/api/proveedores/nvo', [ProveedorController::class, "create"])->name('proveedor.form');
Route::post('/api/proveedores/nvo/guardar',[ProveedorController::class, 'store'])->name('proveedor.crear');

Route::get('/', function () {
    return view('welcome');
});
