<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Lista de empleados</h1>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Fecha de registro</th>
                    <th>Telefono</th>
                    <th>correo</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($lstProveedores as $proveedores)
                    <tr>
                        <td>{{ $proveedores->id }}</td>
                        <td>{{ $proveedores->nombre }}</td>
                        <td>{{ $proveedores->fecheRegistro }}</td>
                        <td>{{ $proveedores->telefono }}</td>
                        <td>{{ $proveedores->correo }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div style="margin-top: 50px">
        <form action="{{ route('proveedor.form') }}" method="GET">
            <button type="submit" class="btn btn-primary">Crear proveedor</button>
        </form>
    </div>

    
</body>
</html>