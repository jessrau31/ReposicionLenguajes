<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Lista de productos</h1>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Descripcion</th>
                    <th>Precio</th>
                    <th>stock</th>
                    <th>Paga ISV</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($lstProductos as $producto)
                    <tr>
                        <td>{{ $producto->descripcion }}</td>
                        <td>{{ $producto->precio }}</td>
                        <td>{{ $producto->stock }}</td>
                        <td>{{ $producto->pagaIsv }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div style="margin-top: 50px">
        <form action="{{ route('producto.form') }}" method="GET">
            <button type="submit" class="btn btn-primary">Crear producto</button>
        </form>
    </div>

    
</body>
</html>