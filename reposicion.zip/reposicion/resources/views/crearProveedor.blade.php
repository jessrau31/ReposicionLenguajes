<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Crear empleado</h2>
    <form method="POST", action="{{route('proveedor.crear') }}" class="form">
        @csrf 
        <div>
            <label>Id</label>
            <input type="number" id="id" name="id">
        </div>
        <div>
            <label>Nombre</label>
            <input type="text" id="nombre" name="nombre">
        </div>

        <div>
            <label>Fecha de registro</label>
            <input type="date" id="fechaRegistro" name="fechaRegistro">
        </div>

        <div>
            <label>Telefono</label>
            <input type="text" id="telefono" name="telefono">
        </div>

        <div>
            <label>correo</label>
            <input type="mail" id="correo" name="correo">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</body>
</html>