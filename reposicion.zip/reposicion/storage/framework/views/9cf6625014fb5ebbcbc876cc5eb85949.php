<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Crear empleado</h2>
    <form method="POST", action="<?php echo e(route('empleado.crear')); ?>" class="form">
        <?php echo csrf_field(); ?> 
        <div>
            <label>Id</label>
            <input type="number" id="id" name="id">
        </div>

        <div>
            <label>Nombre</label>
            <input type="text" id="nombre" name="nombre">
        </div>

        <div>
            <label>Apellido</label>
            <input type="text" id="apellido" name="apellido">
        </div>

        <div>
            <label>Fecha de ingreso</label>
            <input type="date" id="fechaIngreso" name="fechaIngreso">
        </div>

        <div>
            <label>Salario</label>
            <input type="number" id="salario" name="salario">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\reposicion\resources\views/crearEmpleado.blade.php ENDPATH**/ ?>