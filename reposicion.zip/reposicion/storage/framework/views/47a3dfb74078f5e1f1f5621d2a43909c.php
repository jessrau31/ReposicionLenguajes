<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Crear Producto</h2>
    <form method="POST", action="<?php echo e(route('producto.crear')); ?>" class="form">
        <?php echo csrf_field(); ?> 
        <div>
            <label>Descripcion</label>
            <input type="text" id="descripcion" name="descripcion">
        </div>

        <div>
            <label>Precio</label>
            <input type="number" id="precio" name="precio">
        </div>

        <div>
            <label>Stock</label>
            <input type="number" id="stock" name="stock">
        </div>

        <div>
            <label>PagaIsv</label>
            <input type="number" id="pagaIsv" name="pagaIsv">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\reposicion\resources\views/crearProductos.blade.php ENDPATH**/ ?>