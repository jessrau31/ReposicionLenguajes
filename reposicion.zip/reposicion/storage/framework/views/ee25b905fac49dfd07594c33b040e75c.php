<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Lista de productos</h1>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Descripcion</th>
                    <th>Precio</th>
                    <th>stock</th>
                    <th>Paga ISV</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lstProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->descripcion); ?></td>
                        <td><?php echo e($producto->precio); ?></td>
                        <td><?php echo e($producto->stock); ?></td>
                        <td><?php echo e($producto->pagaIsv); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top: 50px">
        <form action="<?php echo e(route('producto.form')); ?>" method="GET">
            <button type="submit" class="btn btn-primary">Crear producto</button>
        </form>
    </div>

    
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\reposicion\resources\views/productos.blade.php ENDPATH**/ ?>