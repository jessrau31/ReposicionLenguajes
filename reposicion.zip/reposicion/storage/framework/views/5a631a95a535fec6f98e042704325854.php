<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Lista de empleados</h1>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Fecha de ingreso</th>
                    <th>Salario</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lstEmpleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($empleado->id); ?></td>
                        <td><?php echo e($empleado->nombre); ?></td>
                        <td><?php echo e($empleado->apellido); ?></td>
                        <td><?php echo e($empleado->fechaIngreso); ?></td>
                        <td><?php echo e($empleado->salario); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top: 50px">
        <form action="<?php echo e(route('empleado.form')); ?>" method="GET">
            <button type="submit" class="btn btn-primary">Crear empleado</button>
        </form>
    </div>

    
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\reposicion\resources\views/empleados.blade.php ENDPATH**/ ?>